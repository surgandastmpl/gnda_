<h2>Add Category</h2>

<form action="kat_proses.php" method="post">
    <table>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="cat_name"></td>
        </tr>
        <tr>
            <td>KETERANGAN</td>
            <td><textarea name="cat_text" id="" cols="30" rows="10"></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>